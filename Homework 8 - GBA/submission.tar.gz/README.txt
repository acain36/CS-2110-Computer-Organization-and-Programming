This is a racing game! 
Press ENTER to start the game! 
Don't run into the walls or you will lose and have a generally bad day :(
If you can avoid the walls and make it to the blue finish line by using the arrow keys, you are winner of EVERYTHING!!
Backspace at any time to return to the start if you are unsatisfied with your performance.