/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=15x30 racecar racecar.png 
 * Time-stamp: Monday 04/04/2022, 22:21:50
 * 
 * Image Information
 * -----------------
 * racecar.png 15@30
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef RACECAR_H
#define RACECAR_H

extern const unsigned short racecar[450];
#define RACECAR_SIZE 900
#define RACECAR_LENGTH 450
#define RACECAR_WIDTH 15
#define RACECAR_HEIGHT 30

#endif

